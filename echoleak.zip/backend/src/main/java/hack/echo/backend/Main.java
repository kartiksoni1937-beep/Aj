package hack.echo.backend;

import java.util.concurrent.ExecutionException;

public class Main {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        Backend.getInstance().start();
    }
}
