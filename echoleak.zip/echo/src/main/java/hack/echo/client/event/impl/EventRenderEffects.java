package hack.echo.client.event.impl;

import hack.echo.client.event.Event;

public class EventRenderEffects extends Event {
}
